/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50639
 Source Host           : localhost:3306
 Source Schema         : ssm_fwzl

 Target Server Type    : MySQL
 Target Server Version : 50639
 File Encoding         : 65001

 Date: 21/02/2021 12:20:08
*/

drop database if exists ssm_fwzl;
create database ssm_fwzl charset utf8;
use ssm_fwzl;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `adminid` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `realname` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
BEGIN;
INSERT INTO `admin` VALUES ('1', 'admin', 'admin', '管理员', '13888888888');
INSERT INTO `admin` VALUES ('A20210220214608782', 'tom', '123', '汤姆', '1399999999');
INSERT INTO `admin` VALUES ('A20210220214619194', 'jack', '123', '杰克', '13777777777');
COMMIT;

-- ----------------------------
-- Table structure for article
-- ----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `articleid` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `contents` text,
  `addtime` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article
-- ----------------------------
BEGIN;
INSERT INTO `article` VALUES ('A20210220213616964', '热点一二线城市接连出台调控，2021年楼市走向', 'upfiles/20210220225437.jpg', '<p><span style=\"font-family:微软雅黑,microsoft yahei\">1月21日晚，楼市持续火爆的上海突发调控政策，八大部门联合印发《关于促进本市房地产市场平稳健康发展的意见》，涉及土地、限购、信贷、税费等9条主要内容。</span></p>\r\n\r\n<p><strong><span style=\"font-family:微软雅黑,microsoft yahei\">政策核心内容：</span></strong></p>\r\n\r\n<p><span style=\"color:rgb(192, 0, 0); font-family:微软雅黑,microsoft yahei\">1、夫妻离异的，任何一方自夫妻离异之日起3年内购买商品住房的，其拥有住房套数按离异前家庭总套数计算。</span></p>\r\n\r\n<p><span style=\"color:rgb(192, 0, 0); font-family:微软雅黑,microsoft yahei\">2、将个人对外销售住房增值税征免年限从2年提高至5年。</span></p>\r\n\r\n<p><span style=\"font-family:微软雅黑,microsoft yahei\">3、完善新建商品住房公证摇号选房制度，优先满足&ldquo;无房家庭&rdquo;自住购房需求。</span></p>\r\n\r\n<p><span style=\"font-family:微软雅黑,microsoft yahei\">4、严格执行差别化住房信贷政策，对购房人首付资金来源、债务收入比加大核查力度。</span></p>\r\n\r\n<p><span style=\"font-family:微软雅黑,microsoft yahei\">除了上海外，近期深圳、南京也都出台了楼市调控新政，广州官方喊话坚持房住不炒；从2021年开端来看，今年楼市大方向是收紧&hellip;&hellip;</span></p>\r\n', '2021-12-20', '5');
INSERT INTO `article` VALUES ('A20210220213808578', '南京最新人才购房政策出炉！', 'upfiles/20210220225423.jpg', '<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">2021年1月16日，南京发布了最新版人才购房政策！与此前相比，主要变化有三点，政策有所收紧！</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"background-color:rgb(255, 192, 0); font-family:微软雅黑,microsoft yahei\"><strong>变化内容</strong></span></p>\r\n\r\n<p style=\"text-align:justify\"><strong><span style=\"font-family:微软雅黑,microsoft yahei; font-size:14px\">1、房屋的认定有微调</span></strong></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">供应对象中南京户籍相当于A、B、C类的高层次人才家庭，<span style=\"color:rgb(192, 0, 0); font-size:14px\">房屋的认定有微调：在南京无自有产权住房或仅有1套住房，这次是降低了要求。此前要求在南京无房或仅有1套房且面积在90平方米以下。</span></span></p>\r\n\r\n<p style=\"text-align:justify\"><strong><span style=\"font-family:微软雅黑,microsoft yahei; font-size:14px\">2、明确社保或个税缴纳的时间要求</span></strong></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"color:rgb(192, 0, 0); font-family:微软雅黑,microsoft yahei\">取得硕士学位的人才，需在宁缴纳社保或个税6个月；45周岁以下取得本科学历的人才，需在宁缴纳社保或个税12个月。此前这两类人才对缴纳社保或个税并没有时间要求。</span></p>\r\n\r\n<p style=\"text-align:justify\"><strong><span style=\"font-family:微软雅黑,microsoft yahei; font-size:14px\">3、对骗取人才购房证明的惩罚变重</span></strong></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">伙同他人弄虚作假骗取《人才购房证明》的，取消该企业所有人才购房申请资格；</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">如有弄虚作假，虚报瞒报，取消人才购房资格，未购房的注销其《人才购房证明》，已选房或认购的收回房源，已签约的不予合同备案。</span></p>\r\n', '2021-12-20', '2');
INSERT INTO `article` VALUES ('A20210220214114322', '二手房交易税费一览', 'upfiles/20210220225407.png', '<p>二手房交易税费是指在二手房交易中，税务部门向买卖双方征收的各类税费。目前，南京二手房交易需要缴纳税费包括契税、增值税、个人所得税、房屋产权登记费、土地增值税、印花税等。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><span style=\"background-color:rgb(255, 192, 0)\"><strong>一、二手房交易税费</strong></span></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1、契税</strong></p>\r\n\r\n<table style=\"border-collapse:collapse; color:rgb(41, 43, 51); font-family:microsoft yahei,微软雅黑,hiragino sans gb,tahoma,arial,宋体,simsun,sans-serif; font-size:12px; width:601px\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"3\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">类别</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">契税税率</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"5\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">住宅</td>\r\n			<td rowspan=\"2\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">家庭唯一住房</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">90㎡以下（含90㎡）</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">计税价格/1.05*1%</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">90㎡以上</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">计税价格/1.05*1.5%</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">二套房</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">90㎡以下（含90㎡）</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">计税价格/1.05*1%</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">90㎡以上</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">计税价格/1.05*2%</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">三套及以上</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">不分面积</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">计税价格/1.05*3%</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">非住宅</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">不分面积</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">计税价格/1.05*3%</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2、增值税</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table style=\"border-collapse:collapse; color:rgb(41, 43, 51); font-family:microsoft yahei,微软雅黑,hiragino sans gb,tahoma,arial,宋体,simsun,sans-serif; font-size:12px; width:437px\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">类别</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">税率</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"2\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">住宅</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">满2年</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">免征</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">不满2年</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">计税价格/1.05*5.3%</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>3、个人所得税</strong></p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<table style=\"border-collapse:collapse; color:rgb(41, 43, 51); font-family:microsoft yahei,微软雅黑,hiragino sans gb,tahoma,arial,宋体,simsun,sans-serif; font-size:12px; width:544px\">\r\n	<tbody>\r\n		<tr>\r\n			<td colspan=\"3\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">类别</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">税费</td>\r\n		</tr>\r\n		<tr>\r\n			<td rowspan=\"3\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">住宅</td>\r\n			<td rowspan=\"2\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">满5年</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">家庭唯一</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">免征</td>\r\n		</tr>\r\n		<tr>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">家庭非唯一</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">查实征收或核定征收</td>\r\n		</tr>\r\n		<tr>\r\n			<td colspan=\"2\" style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">不满5年</td>\r\n			<td style=\"border-color:rgb(0, 0, 0); text-align:center; vertical-align:middle\">查实征收或核定征收</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n\r\n<p>查实征收：纳税人能够提供房屋原值等费用发票，个税=计税价格-原值-契税-附加-相关费用*20%</p>\r\n\r\n<p>核定征收：纳税人不能提供房屋原值等费用发票，个税=计税价格*1%</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>4、土地增值税</strong></p>\r\n\r\n<p>针对商业性质房源，缴纳计税价格*5%或差额的30%-60%</p>\r\n', '2021-12-20', '3');
INSERT INTO `article` VALUES ('A20210220221222339', '如何给房屋报价和谈价？教你卖出好价钱！', 'upfiles/20210220225352.jpg', '<p>卖房时，应该如何给房屋报价和谈价？教你卖出好价钱！</p>\r\n\r\n<p><strong>一、如何给房屋合理报价？</strong></p>\r\n\r\n<p><strong>1、通过中介估价</strong></p>\r\n\r\n<p>中介一般经验比较丰富，也有代售房源信息，同时了解同区域的供需情况以及客户购买能力，可以综合卖房者的自身情况建议一个较为合理的房屋总价。因此，选择靠谱中介很重要，可以选择成交量大、口碑好的中介公司。</p>\r\n\r\n<p><strong>2、登录官网自行估价</strong></p>\r\n\r\n<p>作为二手房交易买卖的行业大咖，我爱我家官网运用大数据作为数据计算基础和参考，估价可以直接在首页输入小区名称搜索，查出的均价乘以你要卖的房屋面积，即为房屋的初步估价。另外，这个初步估价是小区的平均水准，但房源各异，还是要根据房屋的位置、户型、朝向、楼层、装修、税费、付款方式等要素进行价格浮动。</p>\r\n', '2021-12-20', '1');
INSERT INTO `article` VALUES ('A20210220221245478', '卖房时，什么因素会影响房屋价格？', 'upfiles/20210220225341.jpg', '<p>业主在挂牌房源时，房屋价格至关重要，能不能卖个好价是大家最在意的问题，那么什么因素会影响房子的价格？</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>1、地段</strong></p>\r\n\r\n<p>李嘉诚曾说过&ldquo;决定房地产价值的因素，第一是地段，第二是地段，第三还是地段。&rdquo;这句话也被不少地产人奉为至理名言。当该地段已经全部开发完毕，不再有新项目产生的情况下，房产地段本身的稀缺性就会带来不可估量的价值空间。另外，一个规划完善的区域会为本地房产提供2%至5%的加价空间。</p>\r\n\r\n<p>&nbsp;</p>\r\n\r\n<p><strong>2、房龄</strong></p>\r\n\r\n<p>对于二手房来说，房龄对于房价的影响还是比较大的，一般而言次新房的价格较高，其次是5-10年房龄的房子，而超过20年房龄的老房子，售价一般较低。当然，如果是受到市场追捧的供不应求的二手房可能会因为其稀缺性在定价上忽略减分因素。另外，房主为二手房定价时要考虑到当地楼市的整体市场环境。</p>\r\n', '2021-12-20', '1');
INSERT INTO `article` VALUES ('A20210220221351213', '《契税法》正式通过，这六个变化将影响你的房产', 'upfiles/20210220225304.jpg', '<h1><span style=\"color:rgb(192, 0, 0); font-family:微软雅黑,microsoft yahei; font-size:12px\">2020年8月11日，《中华人民共和国契税法》正式通过，自2021年9月1日起施行。本次契税税率标准较以往政策没有变化，最大变化体现在明确了法定继承及婚姻关系免征契税！</span></h1>\r\n\r\n<div class=\"article-box\" style=\"color: rgb(41, 43, 51); font-family: \">\r\n<p>&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\"><strong>一、明确了&ldquo;先税后证&rdquo;</strong></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">《契税法》第11条规定&ldquo;纳税人办理土地、房屋权属登记，不动产登记机构应当查验契税完税、减免税凭证或者有关信息。未按照规定缴纳契税的，不动产登记机构不予办理土地、房屋权属登记。&rdquo;</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">解析：对&ldquo;先税后证&rdquo;流程在法律层面予以规定，并规定不动产登记机构在权属登记时须查验契税完税情况，未税不予办证。</span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><strong><span style=\"font-family:微软雅黑,microsoft yahei\">&nbsp;二、增加了&ldquo;退税规定&rdquo;</span></strong></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">&nbsp;《契税法》第12条规定&ldquo;在依法办理土地、房屋权属登记前，权属转移合同、权属转移合同性质凭证不生效、无效、被撤销或者被解除的，纳税人可以向税务机关申请退还已缴纳的税款，税务机关应当依法办理。&rdquo;</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">解析：对原先契税退税规定予以统一明确，减少实际执行中的争议。如国税函〔2008〕438号规定，法院判决的无效产权转移行为不征契税，判决撤销权证后，退契税。而财税〔2011〕32号又规定，权属变更登记前退房的，退契税；变更登记后退房的，不退契税。</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">此次《契税法》在法律层面明确了退税规定，即退税同时符合以下条件：</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">1、依法办理土地、房屋权属登记前（法定的时间条件）；</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">2、权属转移合同、权属转移合同性质凭证不生效、无效、被撤销或者被解除的（法定的事项条件）；</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">3、纳税人（法定的主体条件）</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">4、须向税务机关申请退还（法定的发起条件）</span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-family:微软雅黑,microsoft yahei\">小贴士：《契税法》第14条规定，契税的征管适用《税收征收管理法》，所以契税退税要按照征管法规定依申请发起。</span></p>\r\n</div>\r\n', '2021-12-20', '2');
COMMIT;

-- ----------------------------
-- Table structure for bbs
-- ----------------------------
DROP TABLE IF EXISTS `bbs`;
CREATE TABLE `bbs` (
  `bbsid` varchar(255) NOT NULL,
  `usersid` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `contents` varchar(255) DEFAULT NULL,
  `addtime` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `repnum` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bbsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of bbs
-- ----------------------------
BEGIN;
INSERT INTO `bbs` VALUES ('B20181113231451827', 'U20181113223348970', '我想找个房子', '<p>我想找个房子</p>\r\n', '2021-12-13 23:14:51', '4', '1');
INSERT INTO `bbs` VALUES ('B20181114005646928', 'U20181113223348970', '想租房子，单居室', '<p>想租房子，单居室</p>\r\n', '2021-12-14 00:56:46', '0', '0');
INSERT INTO `bbs` VALUES ('B20181115183914688', 'U20181115183847681', '求租求租 民宅一套', '<p>自住，单居室</p>\r\n', '2021-12-15 18:39:14', '2', '1');
INSERT INTO `bbs` VALUES ('B20210220223623770', 'U20181113223348970', '自住，求中山东路房屋，两居室', '<p>自住，求中山东路房屋，两居室</p>\r\n', '2021-12-20 22:36:23', '2', '1');
INSERT INTO `bbs` VALUES ('B20210220223654489', 'U20181113223348970', '求北京西路房屋，靠地铁口最好', '<p>求北京西路房屋，靠地铁口最好</p>\r\n', '2021-12-20 22:36:54', '3', '1');
INSERT INTO `bbs` VALUES ('B20210220223736650', 'U20181115183847681', '出租房屋，靠地铁口，两室一厅', '<p>出租房屋，靠地铁口，两室一厅</p>\r\n', '2021-12-20 22:37:36', '0', '0');
INSERT INTO `bbs` VALUES ('B20210220223807805', 'U20181115183847681', '三室二厅，位置好，靠公交站台，50平', '<p>三室二厅，位置好，靠公交站台，50平</p>\r\n', '2021-12-20 22:38:07', '5', '2');
COMMIT;

-- ----------------------------
-- Table structure for cate
-- ----------------------------
DROP TABLE IF EXISTS `cate`;
CREATE TABLE `cate` (
  `cateid` varchar(255) NOT NULL,
  `catename` varchar(255) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `addtime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cate
-- ----------------------------
BEGIN;
INSERT INTO `cate` VALUES ('C20181113203253925', '酒店式公寓', '酒店式公寓', '2021-12-13');
INSERT INTO `cate` VALUES ('C20181115183812885', '普通民宅', '普通民宅', '2021-12-15');
INSERT INTO `cate` VALUES ('C20210220214447915', '商业办公', '商业办公', '2021-12-20');
COMMIT;

-- ----------------------------
-- Table structure for contract
-- ----------------------------
DROP TABLE IF EXISTS `contract`;
CREATE TABLE `contract` (
  `contractid` varchar(255) NOT NULL,
  `cno` varchar(255) DEFAULT NULL,
  `usersid` varchar(255) DEFAULT NULL,
  `houseid` varchar(255) DEFAULT NULL,
  `addtime` varchar(255) DEFAULT NULL,
  `thestart` varchar(255) DEFAULT NULL,
  `theend` varchar(255) DEFAULT NULL,
  `files` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`contractid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of contract
-- ----------------------------
BEGIN;
INSERT INTO `contract` VALUES ('C20181115184111420', 'C20181115184101979', 'U20181115183847681', 'H20181115184028766', '2021-12-15', '2021-12-15', '2021-12-30', 'upfiles/20181115184106.docx', '完成');
INSERT INTO `contract` VALUES ('C20210220223034462', 'C20210220223009187', 'U20181113223348970', 'H20210220215829999', '2021-12-20', '2021-12-17', '2021-12-25', 'upfiles/20210220223027.jpeg', '完成');
INSERT INTO `contract` VALUES ('C20210220223101434', 'C20210220223034254', 'U20181113223348970', 'H20210220220638294', '2021-12-20', '2021-12-21', '2021-07-22', 'upfiles/20210220223044.jpg', '完成');
INSERT INTO `contract` VALUES ('C20210220223502244', 'C20210220223350961', 'U20181113223348970', 'H20210220215220645', '2021-12-20', '2021-12-23', '2021-06-24', 'upfiles/20210220223453.jpeg', '完成');
INSERT INTO `contract` VALUES ('C20210220230641330', 'C20210220230611101', 'U20181113223348970', 'H20181113231340901', '2021-12-20', '2021-12-26', '2021-03-11', 'upfiles/20210220230633.jpg', '未完成');
INSERT INTO `contract` VALUES ('C20210220230706114', 'C20210220230641174', 'U20181113223348970', 'H20181113231421866', '2021-12-20', '2021-12-05', '2021-12-17', 'upfiles/20210220230657.jpg', '完成');
INSERT INTO `contract` VALUES ('C20210220230736430', 'C20210220230716636', 'U20181113223348970', 'H20210220220959160', '2021-12-20', '2021-01-14', '2021-12-05', 'upfiles/20210220230727.jpg', '完成');
COMMIT;

-- ----------------------------
-- Table structure for house
-- ----------------------------
DROP TABLE IF EXISTS `house`;
CREATE TABLE `house` (
  `houseid` varchar(255) NOT NULL,
  `usersid` varchar(255) DEFAULT NULL,
  `housename` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `cateid` varchar(255) DEFAULT NULL,
  `mianji` varchar(255) DEFAULT NULL,
  `louceng` varchar(255) DEFAULT NULL,
  `chaoxiang` varchar(255) DEFAULT NULL,
  `addtime` varchar(255) DEFAULT NULL,
  `hits` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `contents` text,
  PRIMARY KEY (`houseid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of house
-- ----------------------------
BEGIN;
INSERT INTO `house` VALUES ('H20181113231340901', 'U20181113223348970', '高新园区 万达广场', 'upfiles/20181113231315.jpg', '2500', 'C20181113203253925', '45', '5/16', '南北', '2018-11-13', '0', '出租', '<p>(单间出租)高新园区 万达广场 雯君庭 纳米大厦 中海紫御官邸 单间合厨(随时看房,交通便利,干净卫生,独立卫浴)</p>\r\n');
INSERT INTO `house` VALUES ('H20181113231421866', 'U20181113223348970', '奥林匹克广场白云新村 2室1厅', 'upfiles/20181113231403.jpg', '4500', 'C20181113203253925', '55', '5/16', '南北', '2018-11-13', '0', '待租', '<p>奥林匹克广场白云新村 2室1厅1400平米 中等装修(奥林匹克广场 白云新村 两室双南巷 采光好 室内)</p>\r\n');
INSERT INTO `house` VALUES ('H20181115184028766', 'U20181115183847681', '1室1厅78平米', 'upfiles/20181115184005.jpg', '5600', 'C20181115183812885', '78', '5/16', '南北', '2018-11-15', '1', '待租', '<p>友好广场中心裕景,一 1室1厅78平米 豪华装修 押一付三</p>\r\n');
INSERT INTO `house` VALUES ('H20210220215220645', 'U20181113223348970', '珠江路如意里居家装修南北通透', 'upfiles/20210220225535.jpg', '4000', 'C20181115183812885', '50', '3', '南', '2021-12-20', '0', '待租', '<ul>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">房源亮点</span>居家装修，拎包入住，价格可谈</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">户型介绍</span>此房为南向二室一厅一卫，50平米，精装，主卧朝南，次卧朝 ，全明小户型</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">交通出行</span>距离地铁浮桥站直线距离280米。，靠近太平北路公交站台，出行方便</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">周边配套</span>相府营菜场，1912，大行宫</li>\r\n</ul>\r\n');
INSERT INTO `house` VALUES ('H20210220215435644', 'U20181113223348970', '紫金山脚有氧呼吸精装三房家电齐全拎包入住诚租', 'upfiles/20210220225551.jpg', '7000', 'C20181115183812885', '149', '3', '南', '2021-12-20', '1', '待租', '<ul>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">房源亮点</span>三开间朝南，居住舒适，好楼层，视野好</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">户型介绍</span>此房为南北向三室二厅二卫，149平米，精装，南北向三室一厅，三开间朝南，边户客厅全明。</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">交通出行</span>距离地铁马群站直线距离879米，周边交通便捷，5路，51路，164路，163路，141路，139路，142路，179路，310路，121路，55路等</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">周边配套</span>小区周边花园城，苏果，菜市场，幸福蓝海电影院，紫金山，海底世界，周边有乐妍幼儿园，钟山学院，中西医结合医院，百水桥医院。</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">小区信息</span>小区地处马群枢纽地段，靠近紫金山，绿化好，空气清新，环境优美，物业安全</li>\r\n</ul>\r\n');
INSERT INTO `house` VALUES ('H20210220215829999', 'U20181113223348970', '精装修带家具 拎包办公 业主直租', 'upfiles/20210220225615.jpg', '3 元/m²/天', 'C20210220214447915', '1000㎡ ', '15', '北', '2021-12-20', '0', '待租', '<p><span style=\"color:rgb(26, 26, 166); font-family:monospace; font-size:medium\">精装修带家具 拎包办公 业主直租出租电话4008896173,0002,租金价格3元/㎡/天,我爱我家办公楼租赁频道实时更新精装修带家具 拎包办公 业主直租租金、物业费、停车费等相关信息，敬请关注！</span></p>\r\n');
INSERT INTO `house` VALUES ('H20210220220314450', 'U20181113223348970', '新街口商圈 华泰证券大厦 双地铁 户型方正 精装修带家具', 'upfiles/20210220225632.jpg', '2 元/m²/天', 'C20210220214447915', '800㎡ ', '10', '南', '2021-12-20', '0', '待租', '<p><span style=\"color:rgb(26, 26, 166); font-family:monospace; font-size:medium\">精装修带家具 拎包办公 业主直租出租电话4008896173,0002,租金价格3元/㎡/天,我爱我家南京办公楼租赁频道实时更新精装修带家具 拎包办公 业主直租租金、物业费、停车费等相关信息，敬请关注！</span></p>\r\n');
INSERT INTO `house` VALUES ('H20210220220316943', 'U20181113223348970', '天时国际 精装修 大开间 全明采光 交通便利', 'upfiles/20210220225646.jpg', '4 元/m²/天', 'C20210220214447915', '800㎡ ', '13', '北', '2021-12-20', '0', '待租', '<p><span style=\"color:rgb(26, 26, 166); font-family:monospace; font-size:medium\">精装修带家具 拎包办公 业主直租出租电话4008896173,0002,租金价格3元/㎡/天,我爱我家南京办公楼租赁频道实时更新精装修带家具 拎包办公 业主直租租金、物业费、停车费等相关信息，敬请关注！</span></p>\r\n');
INSERT INTO `house` VALUES ('H20210220220324725', 'U20181113223348970', '常府街 凤凰和睿大厦 精装修 大开间 高区视野好 随时看房', 'upfiles/20210220225701.jpg', '1.5元/m²/天', 'C20210220214447915', '800㎡ ', '3', '南', '2021-12-20', '1', '待租', '<p><span style=\"color:rgb(26, 26, 166); font-family:monospace; font-size:medium\">精装修带家具 拎包办公 业主直租出租电话4008896173,0002,租金价格3元/㎡/天,我爱我家南京办公楼租赁频道实时更新精装修带家具 拎包办公 业主直租租金、物业费、停车费等相关信息，敬请关注！</span></p>\r\n');
INSERT INTO `house` VALUES ('H20210220220456380', 'U20181113223348970', '城开大厦 随时可看 拎包办公 交通便利 户型方正', 'upfiles/20210220225723.jpg', '3 元/m²/天', 'C20210220214447915', '1000㎡ ', '15', '北', '2021-12-20', '0', '待租', '<p><span style=\"color:rgb(26, 26, 166); font-family:monospace; font-size:medium\">精装修带家具 拎包办公 业主直租出租电话4008896173,0002,租金价格3元/㎡/天,我爱我家南京办公楼租赁频道实时更新精装修带家具 拎包办公 业主直租租金、物业费、停车费等相关信息，敬请关注！</span></p>\r\n');
INSERT INTO `house` VALUES ('H20210220220638294', 'U20181113223348970', '整租·北京东路·兰园·3居室', 'upfiles/20210220231619.jpg', '4000', 'C20181113203253925', '50', '3', '南', '2021-12-20', '0', '待租', '<ul>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">房源亮点</span>相寓深植房屋资产管理领域，持续打造广布全国的高品质租住空间，海量房源，多元产品选择，以贴心品质服务为客户缔造美好租+生活</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">交通出行</span>距离地铁鸡鸣寺站直线距离307米</li>\r\n</ul>\r\n');
INSERT INTO `house` VALUES ('H20210220220956238', 'U20181113223348970', '凤凰西街 凤凰花园城精装两房家具齐全拎包入住', 'upfiles/20210220225839.jpg', '12000', 'C20181115183812885', '140', '10', '北', '2021-12-20', '0', '待租', '<ul>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">房源亮点</span>保利紫晶山四房两厅两卫 精装装修保养好，品牌家具家电，诚心出租，看房方便。</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">户型介绍</span>此房为南北向四室二厅三卫，190平米，精装，交通便利，看房方便</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">交通出行</span>距离地铁仙鹤门站直线距离354米。，交通四通八达，多路公交出行。</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">周边配套</span>仙鹤门，仙林湖，金马路，金鹰奥莱城，南师，多路公交车出行</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">小区信息</span>小区环境优美，由电梯入户花园洋房和别墅组成，环境优美，离仙鹤门一路之隔，生活方便，出行方便</li>\r\n</ul>\r\n');
INSERT INTO `house` VALUES ('H20210220220959160', 'U20181113223348970', '保利紫晶山 南外旁精装修家具家电齐全 诚心租', 'upfiles/20210220225745.jpg', '5000', 'C20181115183812885', '120', '8', '南', '2021-12-20', '3', '待租', '<ul>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">房源亮点</span>保利紫晶山四房两厅两卫 精装装修保养好，品牌家具家电，诚心出租，看房方便。</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">户型介绍</span>此房为南北向四室二厅三卫，190平米，精装，交通便利，看房方便</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">交通出行</span>距离地铁仙鹤门站直线距离354米。，交通四通八达，多路公交出行。</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">周边配套</span>仙鹤门，仙林湖，金马路，金鹰奥莱城，南师，多路公交车出行</li>\r\n	<li><span style=\"color:rgb(142, 153, 169); font-size:14px\">小区信息</span>小区环境优美，由电梯入户花园洋房和别墅组成，环境优美，离仙鹤门一路之隔，生活方便，出行方便</li>\r\n</ul>\r\n');
COMMIT;

-- ----------------------------
-- Table structure for rebbs
-- ----------------------------
DROP TABLE IF EXISTS `rebbs`;
CREATE TABLE `rebbs` (
  `rebbsid` varchar(255) NOT NULL,
  `usersid` varchar(255) DEFAULT NULL,
  `bbsid` varchar(255) DEFAULT NULL,
  `contents` varchar(255) DEFAULT NULL,
  `addtime` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`rebbsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of rebbs
-- ----------------------------
BEGIN;
INSERT INTO `rebbs` VALUES ('R20181114005651959', 'U20181113223348970', 'B20181113231451827', '<p>在此添加内容水电费感受到法国</p>\r\n', '2021-12-14 00:56:51');
INSERT INTO `rebbs` VALUES ('R20181115183931893', 'U20181115183847681', 'B20181115183914688', '<p>在此添加内容；就是的发送到发送到发</p>\r\n', '2021-12-15 18:39:31');
INSERT INTO `rebbs` VALUES ('R20210220224048692', 'U20181115183847681', 'B20210220223654489', '<p>同求</p>\r\n', '2021-12-20 22:40:48');
INSERT INTO `rebbs` VALUES ('R20210220224122847', 'U20181115183847681', 'B20210220223623770', '<p><span style=\"color:rgb(0, 0, 0); font-family:helvetica,sans-serif,宋体; font-size:12px\">怎么联系你啊</span></p>\r\n', '2021-12-20 22:41:22');
INSERT INTO `rebbs` VALUES ('R20210220224145339', 'U20181113223348970', 'B20210220223807805', '<p><span style=\"color:rgb(0, 0, 0); font-family:helvetica,sans-serif,宋体; font-size:12px\">怎么联系你啊，我想租</span></p>\r\n', '2021-12-20 22:41:45');
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `usersid` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `realname` varchar(255) DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `birthday` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `regdate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`usersid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` VALUES ('U20181113223348970', 'zhangsan', '123', '张三', '男', '1994-4-13', '12345678', 'upfiles/20181113223347.jpg', '2021-2-13');
INSERT INTO `users` VALUES ('U20181115183847681', 'lisi', '123', '李四', '男', '1987-7-21', '12345678', 'upfiles/20181115183846.jpg', '2021-2-20');
INSERT INTO `users` VALUES ('U20210220214903563', 'wangwu', '123', '王五', '男', '1995-02-10', '12345678', 'upfiles/20210220214901.jpg', '2021-12-20');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
